﻿using System;
using System.Diagnostics;
using System.Threading;

class Program
{
    const int NumThreads = 4;
    const int IncrementsPerThread = 1_000_000;

    static long counter = 0;
    static readonly object counterLock = new object();

    static void LockWorker()
    {
        for (int i = 0; i < IncrementsPerThread; i++)
        {
            lock (counterLock)
            {
                counter++;
            }
        }
    }

    static void InterlockedWorker()
    {
        for (int i = 0; i < IncrementsPerThread; i++)
        {
            Interlocked.Increment(ref counter);
        }
    }

    static double RunVersion(ThreadStart worker)
    {
        counter = 0;

        Thread[] threads = new Thread[NumThreads];

        Stopwatch sw = Stopwatch.StartNew();

        for (int i = 0; i < NumThreads; i++)
        {
            threads[i] = new Thread(worker);
            threads[i].Start();
        }

        for (int i = 0; i < NumThreads; i++)
        {
            threads[i].Join();
        }

        sw.Stop();

        long expected = (long)NumThreads * IncrementsPerThread;

        Console.WriteLine($"Expected: {expected}");
        Console.WriteLine($"Actual: {counter}");
        Console.WriteLine($"Correct: {counter == expected}");
        Console.WriteLine($"Time: {sw.Elapsed.TotalMilliseconds:F2} ms");

        return sw.Elapsed.TotalMilliseconds;
    }

    static void Main()
    {
        Console.WriteLine("LOCK");
        RunVersion(LockWorker);

        Console.WriteLine("\nINTERLOCKED");
        RunVersion(InterlockedWorker);
    }
}
